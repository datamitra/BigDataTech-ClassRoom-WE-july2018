package com.bdt;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

//Import files from
//hadoop2.9.1/share/hadoop
// 1) common -3jars
// 2)common/lib -all
//3) hdfs -> only jars
//4) mapreduce -> onlhy jars
//5) yarn -> jar

public class WordCountMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
//byteoffset,line kin,vin and   word,1 as k,v out
	@Override
	protected void map(LongWritable key, Text value, 
			Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		
		//0, hi welcome to class
		String line=value.toString(); //convert hadoop types in to java types
		//MapReduce works with row formats only
		StringTokenizer words=new StringTokenizer(line, " "); // divide lines into words
		
		while(words.hasMoreTokens()){
			String word=words.nextToken();
			context.write(new Text(word), new IntWritable(1));
			//hi,1   welcome,1 
		}
	
	}
	

}
