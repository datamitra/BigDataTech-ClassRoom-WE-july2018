package com.bdt;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class WordCountDriver {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		//hadoop behaviour depends on Configuration
		Configuration conf=new Configuration();
		//who represents the mr job, JOB object
		Job job=Job.getInstance(conf, "wordcount example");
		job.setJarByClass(WordCountDriver.class); //main class file name
		job.setMapperClass(WordCountMapper.class);
		job.setReducerClass(WordCountReducer.class);
		
		// mention the output types when job input and output types are different
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		
		//hadoop jar jarfile mainclassfilename inputpath outputpath
		
		boolean res=job.waitForCompletion(true);
		int status=res?0:1;
		System.exit(status);
		
	}

}
